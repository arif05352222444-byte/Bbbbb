package com.arif.ledtvbanner

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.util.SystemUiHelper

/**
 * Opening logo / splash screen ("Aysel'in Gözleri").
 * Shows the logo full-screen on black for ~4 seconds with a gentle fade,
 * then automatically opens the main menu. The user does not press anything.
 *
 * This is the launcher activity; it only adds the intro and does NOT change
 * any existing menu, banner, music or YouTube logic.
 */
class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var navigated = false

    // ~4 seconds total: fade-in (0-700ms), hold, fade-out (3500-4000ms).
    private val holdUntilFadeOut = 3500L
    private val fadeInMs = 700L
    private val fadeOutMs = 500L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Full screen + keep screen awake during the intro.
        SystemUiHelper.enterImmersive(this, true)

        val image = findViewById<ImageView>(R.id.splashImage)
        image.alpha = 0f
        image.animate().alpha(1f).setDuration(fadeInMs).start()

        handler.postDelayed({ fadeOutAndContinue(image) }, holdUntilFadeOut)
    }

    private fun fadeOutAndContinue(image: ImageView) {
        image.animate()
            .alpha(0f)
            .setDuration(fadeOutMs)
            .withEndAction { goToMainMenu() }
            .start()
    }

    private fun goToMainMenu() {
        if (navigated) return
        navigated = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    /** Any remote key (OK / Back) skips the intro straight to the menu. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        goToMainMenu()
        return true
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        SystemUiHelper.clearKeepScreenOn(this)
        super.onDestroy()
    }
}
