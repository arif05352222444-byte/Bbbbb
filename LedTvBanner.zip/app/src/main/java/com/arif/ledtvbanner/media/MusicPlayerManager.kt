package com.arif.ledtvbanner.media

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/**
 * Single source of truth for background audio. Uses Media3 ExoPlayer so local
 * files (MP3/AAC/M4A/WAV) and internet radio streams (MP3/AAC/HLS) all play
 * through one robust engine. Only one source plays at a time.
 */
class MusicPlayerManager(private val context: Context) {

    var onError: ((String) -> Unit)? = null
    private var player: ExoPlayer? = null

    private fun ensure(): ExoPlayer {
        var p = player
        if (p == null) {
            p = ExoPlayer.Builder(context).build()
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    onError?.invoke("Seçilen müzik çalınamadı. Banner müziksiz devam ediyor.")
                }
            })
            player = p
        }
        return p
    }

    fun playUri(uriString: String, loop: Boolean, volume: Int) = playAny(uriString, loop, volume)
    fun playStream(url: String, loop: Boolean, volume: Int) = playAny(url, loop, volume)

    private fun playAny(uri: String, loop: Boolean, volume: Int) {
        try {
            val p = ensure()
            p.repeatMode = if (loop) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
            p.volume = volume.coerceIn(0, 100) / 100f
            p.setMediaItem(MediaItem.fromUri(uri))
            p.prepare()
            p.playWhenReady = true
        } catch (e: Exception) {
            onError?.invoke("Seçilen müzik çalınamadı. Banner müziksiz devam ediyor.")
        }
    }

    fun setVolume(volume: Int) {
        try { player?.volume = volume.coerceIn(0, 100) / 100f } catch (_: Exception) {}
    }

    fun pause() { try { player?.playWhenReady = false } catch (_: Exception) {} }
    fun resume() { try { player?.playWhenReady = true } catch (_: Exception) {} }
    fun stop() { try { player?.stop() } catch (_: Exception) {} }

    fun release() {
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    /**
     * Briefly tries to open a stream/file (muted). Reports success on READY,
     * failure on error or timeout. Uses a separate short-lived player so it
     * never disturbs whatever is currently playing.
     */
    fun test(uri: String, onResult: (Boolean, String) -> Unit) {
        val handler = Handler(Looper.getMainLooper())
        var done = false
        var tester: ExoPlayer? = null
        try {
            tester = ExoPlayer.Builder(context).build()
            val t = tester
            val finish: (Boolean, String) -> Unit = { ok, msg ->
                if (!done) {
                    done = true
                    try { t?.release() } catch (_: Exception) {}
                    onResult(ok, msg)
                }
            }
            val timeout = Runnable { finish(false, "Bu radyo şu an çalmıyor. Başka kanal deneyin.") }
            handler.postDelayed(timeout, 8000)
            t?.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        handler.removeCallbacks(timeout)
                        finish(true, "Radyo bağlantısı başarılı.")
                    }
                }
                override fun onPlayerError(error: PlaybackException) {
                    handler.removeCallbacks(timeout)
                    val unsupported = error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
                    finish(false,
                        if (unsupported) "Bu radyo formatı desteklenmiyor. Başka kanal deneyin."
                        else "Bu radyo şu an çalmıyor. Başka kanal deneyin.")
                }
            })
            t?.volume = 0f
            t?.setMediaItem(MediaItem.fromUri(uri))
            t?.prepare()
            t?.playWhenReady = true
        } catch (e: Exception) {
            try { tester?.release() } catch (_: Exception) {}
            onResult(false, "Bu radyo şu an çalmıyor. Başka kanal deneyin.")
        }
    }
}
