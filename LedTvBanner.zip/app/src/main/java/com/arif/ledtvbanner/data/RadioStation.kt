package com.arif.ledtvbanner.data

data class RadioStation(
    val name: String,
    val country: String,
    val codec: String,
    val bitrate: Int,
    val url: String,
    val tags: String
)
