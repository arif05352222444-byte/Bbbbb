package com.arif.ledtvbanner

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.RadioStation
import com.arif.ledtvbanner.media.MusicPlayerManager
import com.arif.ledtvbanner.media.RadioBrowserClient
import com.arif.ledtvbanner.util.Constants

/**
 * Fetches stations for a category from Radio Browser and shows them as cards.
 * The focused card gets a thick neon border. OK opens Test / Use options.
 */
class RadioStationsActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private lateinit var status: TextView
    private lateinit var player: MusicPlayerManager
    private var category: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_radio_stations)
        player = MusicPlayerManager(this)
        category = intent.getStringExtra(Constants.EXTRA_RADIO_CATEGORY) ?: "Radyo"

        findViewById<TextView>(R.id.tvTitle).text = category
        status = findViewById(R.id.tvStatus)
        container = findViewById(R.id.stationContainer)

        load()
    }

    private fun load() {
        status.text = "Yükleniyor..."
        container.removeAllViews()
        RadioBrowserClient.fetchCategory(category,
            onResult = { stations -> showStations(stations) },
            onError = { msg -> status.text = msg }
        )
    }

    private fun showStations(stations: List<RadioStation>) {
        status.text = "${stations.size} kanal bulundu. Seçmek için kanala gelip OK'a basın."
        container.removeAllViews()
        stations.forEachIndexed { index, st ->
            val card = layoutInflater.inflate(R.layout.item_radio_station, container, false)
            card.findViewById<TextView>(R.id.tvName).text = st.name
            val info = buildString {
                if (st.country.isNotBlank()) append(st.country)
                if (st.codec.isNotBlank()) { if (isNotEmpty()) append("  •  "); append(st.codec) }
                if (st.bitrate > 0) { if (isNotEmpty()) append("  •  "); append("${st.bitrate} kbps") }
            }.ifBlank { "Radyo" }
            card.findViewById<TextView>(R.id.tvInfo).text = info
            card.setOnClickListener { showOptions(st) }
            container.addView(card)
            if (index == 0) card.requestFocus()
        }
    }

    private fun showOptions(st: RadioStation) {
        val options = arrayOf("▶  Test Et", "✓  Bu Kanalı Kullan", "İptal")
        AlertDialog.Builder(this)
            .setTitle(st.name)
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> {
                        Toast.makeText(this, "Test ediliyor...", Toast.LENGTH_SHORT).show()
                        player.test(st.url) { _, msg ->
                            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                    1 -> useStation(st)
                    else -> dialog.dismiss()
                }
            }
            .show()
    }

    private fun useStation(st: RadioStation) {
        val data = Intent()
        data.putExtra(Constants.EXTRA_RADIO_NAME, st.name)
        data.putExtra(Constants.EXTRA_RADIO_URL, st.url)
        setResult(RESULT_OK, data)
        finish()
    }

    override fun onDestroy() {
        try { player.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
