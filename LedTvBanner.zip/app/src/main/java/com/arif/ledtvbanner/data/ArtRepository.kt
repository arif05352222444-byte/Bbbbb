package com.arif.ledtvbanner.data

import com.arif.ledtvbanner.R

/**
 * The built-in art collection. For now just two paintings, no categories.
 * Structured so more items (or categories) can be added later without changes
 * to the screens.
 */
object ArtRepository {

    val items: List<ArtItem> = listOf(
        ArtItem("su_icen_geyik", "Su İçen Geyik", R.drawable.art_su_icen_geyik),
        ArtItem("gunbatimi_gol", "Günbatımı Göl", R.drawable.art_gunbatimi_gol),
        ArtItem("veresiye_pesin", "Veresiye - Peşin Satan", R.drawable.art_veresiye_pesin),
        ArtItem("aglayan_cocuk", "Ağlayan Çocuk", R.drawable.art_aglayan_cocuk)
    )

    fun byId(id: String?): ArtItem? = items.firstOrNull { it.id == id }
}
