package com.arif.ledtvbanner

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.ArtRepository
import com.arif.ledtvbanner.util.Constants

/**
 * Shows one painting full-screen, fit to the screen (ratio preserved) on a dark
 * gallery background with a soft vignette for depth. OK toggles the title,
 * Back returns to the list.
 */
class ArtViewerActivity : AppCompatActivity() {

    private lateinit var tvTitle: TextView
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_art_viewer)

        val item = ArtRepository.byId(intent.getStringExtra(Constants.EXTRA_ART_ID))
            ?: ArtRepository.items.firstOrNull()
        if (item == null) { finish(); return }

        findViewById<ImageView>(R.id.imgArt).setImageResource(item.drawableResId)
        tvTitle = findViewById(R.id.tvTitle)
        tvTitle.text = item.title
        showTitleThenHide()
    }

    private fun showTitleThenHide() {
        tvTitle.visibility = View.VISIBLE
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ tvTitle.visibility = View.GONE }, 2500)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            if (tvTitle.visibility == View.VISIBLE) {
                tvTitle.visibility = View.GONE
                handler.removeCallbacksAndMessages(null)
            } else {
                showTitleThenHide()
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
