package com.arif.ledtvbanner

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.ArtRepository
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.MusicMode
import com.arif.ledtvbanner.media.MusicPlayerManager
import com.arif.ledtvbanner.util.Constants

/** Tablo list — shows the built-in paintings as cards. OK opens fullscreen.
 *  The last selected music plays in the background while in the Tablo section. */
class ArtListActivity : AppCompatActivity() {

    private lateinit var music: MusicPlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_art_list)
        music = MusicPlayerManager(this)
        music.onError = { /* sessizce yut, tablo gösterimi devam etsin */ }

        val container = findViewById<LinearLayout>(R.id.artContainer)
        val margin = (resources.displayMetrics.density * 12).toInt()

        ArtRepository.items.forEachIndexed { index, item ->
            val card = layoutInflater.inflate(R.layout.item_art, container, false)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(margin, margin, margin, margin)
            card.layoutParams = lp

            card.findViewById<TextView>(R.id.tvName).text = item.title
            val img = card.findViewById<ImageView>(R.id.imgPreview)
            val bmp = decodeSampled(item.drawableResId, 700)
            if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(item.drawableResId)

            card.setOnClickListener {
                val i = Intent(this, ArtViewerActivity::class.java)
                i.putExtra(Constants.EXTRA_ART_ID, item.id)
                startActivity(i)
            }
            container.addView(card)
            if (index == 0) card.requestFocus()
        }

        startMusic()
    }

    /** Plays the last-selected background music (MP3 or radio), if any. Keeps
     *  playing while a painting is open; stops when leaving the Tablo section. */
    private fun startMusic() {
        try {
            val cfg = BannerStore(this).getLastUsed() ?: return
            when (cfg.musicMode) {
                MusicMode.LOCAL_MP3 ->
                    if (cfg.musicUri.isNotBlank()) music.playUri(cfg.musicUri, cfg.loop, cfg.volume)
                MusicMode.RADIO ->
                    if (cfg.radioUrl.isNotBlank()) music.playStream(cfg.radioUrl, cfg.loop, cfg.volume)
                else -> { /* Müzik kapalı */ }
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        try { music.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    /** Decode a downscaled preview so the list stays light on memory. */
    private fun decodeSampled(resId: Int, reqW: Int): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeResource(resources, resId, opts)
            var sample = 1
            while (opts.outWidth > 0 && opts.outWidth / sample > reqW) sample *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeResource(resources, resId, o2)
        } catch (e: Exception) {
            null
        }
    }
}
