package com.arif.ledtvbanner

import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.banner.LedBannerView
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.MusicMode
import com.arif.ledtvbanner.data.SettingsStore
import com.arif.ledtvbanner.media.MusicPlayerManager
import com.arif.ledtvbanner.util.Constants
import com.arif.ledtvbanner.util.SystemUiHelper
import org.json.JSONObject

/**
 * The main attraction: full-screen LED sign.
 * - LED text scrolls on top.
 * - Optional MP3 / radio plays in the background.
 * - Controlled entirely by the TV remote (D-pad).
 */
class FullScreenBannerActivity : AppCompatActivity() {

    private lateinit var banner: LedBannerView
    private lateinit var config: BannerConfig
    private lateinit var music: MusicPlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fullscreen)

        val settings = SettingsStore(this)
        SystemUiHelper.enterImmersive(this, settings.keepScreenOn)

        val json = intent.getStringExtra(Constants.EXTRA_BANNER_JSON)
        config = try {
            if (json != null) BannerConfig.fromJson(JSONObject(json)) else BannerConfig()
        } catch (e: Exception) { BannerConfig() }

        BannerStore(this).setLastUsed(config)

        banner = findViewById(R.id.bannerView)
        banner.config = config.copyOf()
        banner.requestFocus()

        music = MusicPlayerManager(this)
        music.onError = { msg ->
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }

        setupMedia()
    }

    private fun setupMedia() {
        when (config.musicMode) {
            MusicMode.OFF -> { /* nothing */ }
            MusicMode.LOCAL_MP3 -> {
                if (config.musicUri.isNotBlank()) {
                    music.playUri(config.musicUri, config.loop, config.volume)
                }
            }
            MusicMode.RADIO -> {
                if (config.radioUrl.isNotBlank()) {
                    music.playStream(config.radioUrl, config.loop, config.volume)
                } else {
                    Toast.makeText(this, "Radyo linki boş.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                banner.togglePause()
                if (banner.isPaused()) music.pause() else music.resume()
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { banner.increaseSpeed(); toast("Hız +"); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { banner.decreaseSpeed(); toast("Hız -"); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { banner.increaseSize(); toast("Boyut +"); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { banner.decreaseSize(); toast("Boyut -"); return true }
            KeyEvent.KEYCODE_BACK -> { finish(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        super.onPause()
        music.pause()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onDestroy() {
        music.release()
        SystemUiHelper.clearKeepScreenOn(this)
        super.onDestroy()
    }
}
