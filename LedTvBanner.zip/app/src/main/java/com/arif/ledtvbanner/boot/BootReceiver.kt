package com.arif.ledtvbanner.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.arif.ledtvbanner.FullScreenBannerActivity
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.SettingsStore
import com.arif.ledtvbanner.util.Constants

/**
 * Optionally launches the last banner when the device boots.
 * Wrapped in try/catch and a settings check so it never crashes the device.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            val settings = SettingsStore(context)
            if (!settings.startOnBoot) return
            val last = BannerStore(context).getLastUsed() ?: return
            val i = Intent(context, FullScreenBannerActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.putExtra(Constants.EXTRA_BANNER_JSON, last.toJson().toString())
            context.startActivity(i)
        } catch (e: Exception) {
            // Some devices block boot-launch; never crash.
        }
    }
}
