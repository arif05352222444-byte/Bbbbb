package com.arif.ledtvbanner

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.SettingsStore
import com.arif.ledtvbanner.util.Constants

/** Android TV main menu (neon card layout). */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Auto-start last banner if enabled in settings.
        val settings = SettingsStore(this)
        if (settings.autoStartLastBanner) {
            val last = BannerStore(this).getLastUsed()
            if (last != null) {
                startFullScreen(last.toJson().toString())
            }
        }

        wireCard(R.id.cardNew) { startActivity(Intent(this, BannerEditorActivity::class.java)) }
        wireCard(R.id.cardSaved) { startActivity(Intent(this, SavedBannersActivity::class.java)) }
        wireCard(R.id.cardQuick) { quickStart() }
        wireCard(R.id.cardMusic) { startActivity(Intent(this, MusicSettingsActivity::class.java)) }
        wireCard(R.id.cardTablo) { startActivity(Intent(this, ArtListActivity::class.java)) }
        wireCard(R.id.cardSettings) { startActivity(Intent(this, SettingsActivity::class.java)) }
        wireCard(R.id.cardExit) { finishAffinity() }

        findViewById<View>(R.id.cardNew).requestFocus()
    }

    /** Hook up click + a subtle scale-up when focused, for TV emphasis. */
    private fun wireCard(id: Int, onClick: () -> Unit) {
        val card = findViewById<View>(id)
        card.setOnClickListener { onClick() }
        card.setOnFocusChangeListener { v, hasFocus ->
            val s = if (hasFocus) 1.06f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(140).start()
        }
    }

    private fun quickStart() {
        val last = BannerStore(this).getLastUsed()
        if (last == null) {
            android.widget.Toast.makeText(
                this, "Henüz kayıtlı banner yok. Önce bir banner oluşturun.",
                android.widget.Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(this, BannerEditorActivity::class.java))
            return
        }
        startFullScreen(last.toJson().toString())
    }

    private fun startFullScreen(json: String) {
        val i = Intent(this, FullScreenBannerActivity::class.java)
        i.putExtra(Constants.EXTRA_BANNER_JSON, json)
        startActivity(i)
    }
}
