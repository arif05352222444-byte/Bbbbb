package com.arif.ledtvbanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.BannerStore
import com.arif.ledtvbanner.data.MusicMode
import com.arif.ledtvbanner.media.MusicPlayerManager
import com.arif.ledtvbanner.util.Constants

/**
 * Background sound for the last used banner.
 * Sources: local/USB audio file, ready-made radio (Radio Browser), manual radio
 * link, or off. YouTube has been removed.
 */
class MusicSettingsActivity : AppCompatActivity() {

    private lateinit var store: BannerStore
    private lateinit var config: BannerConfig
    private lateinit var player: MusicPlayerManager

    private lateinit var tvSelected: TextView
    private lateinit var etRadio: EditText
    private lateinit var seekVolume: SeekBar
    private lateinit var btnLoop: Button

    private val pickMp3 =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                config.musicUri = uri.toString()
                config.musicMode = MusicMode.LOCAL_MP3
                config.musicLabel = "MP3 / " + displayName(uri)
                updateSelected()
                Toast.makeText(this, "Müzik dosyası seçildi.", Toast.LENGTH_SHORT).show()
            }
        }

    private val pickRadio =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val name = result.data?.getStringExtra(Constants.EXTRA_RADIO_NAME) ?: ""
                val url = result.data?.getStringExtra(Constants.EXTRA_RADIO_URL) ?: ""
                if (url.isNotBlank()) {
                    config.radioUrl = url
                    config.radioName = name
                    config.musicMode = MusicMode.RADIO
                    config.musicLabel = "Radyo / " + (if (name.isNotBlank()) name else "Kanal")
                    etRadio.setText(url)
                    updateSelected()
                    Toast.makeText(this, "Radyo seçildi: $name", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)
        store = BannerStore(this)
        config = store.getLastUsed() ?: BannerConfig()
        player = MusicPlayerManager(this)

        tvSelected = findViewById(R.id.tvSelected)
        etRadio = findViewById(R.id.etRadio)
        seekVolume = findViewById(R.id.seekVolume)
        btnLoop = findViewById(R.id.btnLoop)

        etRadio.setText(config.radioUrl)
        seekVolume.progress = config.volume
        updateSelected()
        updateLoop()

        findViewById<Button>(R.id.btnPickMp3).setOnClickListener {
            try {
                pickMp3.launch(arrayOf("audio/*"))
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Bu cihazda dosya seçici açılamadı. USB veya manuel radyo linki kullanabilirsiniz.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        findViewById<Button>(R.id.btnRadioCategories).setOnClickListener {
            pickRadio.launch(Intent(this, RadioCategoriesActivity::class.java))
        }

        findViewById<Button>(R.id.btnTestRadio).setOnClickListener {
            val url = etRadio.text.toString().trim()
            if (url.isBlank()) {
                Toast.makeText(this, "Önce bir radyo linki girin.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Test ediliyor...", Toast.LENGTH_SHORT).show()
                player.test(url) { _, msg -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
            }
        }

        findViewById<Button>(R.id.btnUseRadio).setOnClickListener {
            val url = etRadio.text.toString().trim()
            if (url.isBlank()) {
                Toast.makeText(this, "Önce bir radyo linki girin.", Toast.LENGTH_SHORT).show()
            } else {
                config.radioUrl = url
                config.radioName = "Manuel"
                config.musicMode = MusicMode.RADIO
                config.musicLabel = "Radyo / Manuel link"
                updateSelected()
                Toast.makeText(this, "Manuel radyo seçildi.", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnTestMusic).setOnClickListener { testCurrent() }

        btnLoop.setOnClickListener {
            config.loop = !config.loop
            updateLoop()
        }

        findViewById<Button>(R.id.btnMusicOff).setOnClickListener {
            config.musicMode = MusicMode.OFF
            config.musicLabel = "Müzik Kapalı"
            updateSelected()
            Toast.makeText(this, "Müzik kapatıldı.", Toast.LENGTH_SHORT).show()
        }

        seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { config.volume = p }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnSaveMusic).setOnClickListener { saveAndClose() }

        findViewById<Button>(R.id.btnPickMp3).requestFocus()
    }

    private fun testCurrent() {
        val target = when (config.musicMode) {
            MusicMode.LOCAL_MP3 -> config.musicUri
            MusicMode.RADIO -> config.radioUrl
            else -> ""
        }
        if (target.isBlank()) {
            Toast.makeText(this, "Önce bir müzik kaynağı seçin.", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Test ediliyor...", Toast.LENGTH_SHORT).show()
        player.test(target) { ok, msg ->
            val m = if (ok && config.musicMode == MusicMode.LOCAL_MP3) "Müzik dosyası çalınabiliyor." else msg
            Toast.makeText(this, m, Toast.LENGTH_LONG).show()
        }
    }

    private fun updateSelected() {
        val label = if (config.musicLabel.isNotBlank()) config.musicLabel else config.musicMode.label
        tvSelected.text = "Son seçilen: $label"
    }

    private fun updateLoop() {
        btnLoop.text = "Döngü / Tekrar:  ${if (config.loop) "Açık" else "Kapalı"}"
    }

    private fun displayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else "dosya"
            } ?: "dosya"
        } catch (_: Exception) { "dosya" }
    }

    private fun saveAndClose() {
        // If the user typed a manual link but didn't tap "use", still remember it.
        val typed = etRadio.text.toString().trim()
        if (typed.isNotBlank()) config.radioUrl = typed
        store.setLastUsed(config)
        store.save(config)
        Toast.makeText(this, "Müzik ayarı kaydedildi.", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onDestroy() {
        try { player.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
