package com.arif.ledtvbanner.util

object Constants {
    const val EXTRA_BANNER_JSON = "extra_banner_json"
    const val EXTRA_EDIT_INDEX = "extra_edit_index"
    const val EXTRA_QUICK_START = "extra_quick_start"

    // YouTube search result (no longer used in UI, kept for compatibility)
    const val EXTRA_YT_VIDEO_ID = "extra_yt_video_id"
    const val EXTRA_YT_VIDEO_TITLE = "extra_yt_video_title"

    // Radio
    const val EXTRA_RADIO_CATEGORY = "extra_radio_category"
    const val EXTRA_RADIO_NAME = "extra_radio_name"
    const val EXTRA_RADIO_URL = "extra_radio_url"

    // Tablo (art)
    const val EXTRA_ART_ID = "extra_art_id"
}
