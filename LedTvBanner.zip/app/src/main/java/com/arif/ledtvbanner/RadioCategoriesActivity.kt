package com.arif.ledtvbanner

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arif.ledtvbanner.media.RadioBrowserClient
import com.arif.ledtvbanner.util.Constants

/** Lists the ready-made radio categories. Picking one opens the station list. */
class RadioCategoriesActivity : AppCompatActivity() {

    private val openStations =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                // Relay the chosen station back up to MusicSettings.
                setResult(RESULT_OK, result.data)
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_radio_categories)
        val container = findViewById<LinearLayout>(R.id.catContainer)

        RadioBrowserClient.CATEGORIES.forEachIndexed { index, category ->
            val b = layoutInflater.inflate(R.layout.item_menu_button, container, false) as Button
            b.text = category
            b.setOnClickListener {
                val i = Intent(this, RadioStationsActivity::class.java)
                i.putExtra(Constants.EXTRA_RADIO_CATEGORY, category)
                openStations.launch(i)
            }
            container.addView(b)
            if (index == 0) b.requestFocus()
        }
    }
}
