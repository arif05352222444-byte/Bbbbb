package com.arif.ledtvbanner.data

import androidx.annotation.DrawableRes

/** A single piece of art shown in the Tablo section. */
data class ArtItem(
    val id: String,
    val title: String,
    @DrawableRes val drawableResId: Int
)
