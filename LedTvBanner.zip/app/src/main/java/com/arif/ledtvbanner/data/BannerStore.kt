package com.arif.ledtvbanner.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Saves banners using SharedPreferences (stored as a JSON array).
 * Simple and crash-safe; no database needed for personal use.
 */
class BannerStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("led_banners", Context.MODE_PRIVATE)

    fun getAll(): MutableList<BannerConfig> {
        val raw = prefs.getString(KEY_LIST, "[]") ?: "[]"
        val list = mutableListOf<BannerConfig>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                list.add(BannerConfig.fromJson(arr.getJSONObject(i)))
            }
        } catch (e: Exception) {
            // Corrupt data -> start clean instead of crashing.
        }
        return list
    }

    private fun saveAll(list: List<BannerConfig>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_LIST, arr.toString()).apply()
    }

    /** Add new or update existing (matched by name). */
    fun save(config: BannerConfig) {
        val list = getAll()
        val idx = list.indexOfFirst { it.name == config.name }
        if (idx >= 0) list[idx] = config.copyOf() else list.add(config.copyOf())
        saveAll(list)
        setLastUsed(config)
    }

    fun deleteAt(index: Int) {
        val list = getAll()
        if (index in list.indices) {
            list.removeAt(index)
            saveAll(list)
        }
    }

    fun setLastUsed(config: BannerConfig) {
        prefs.edit().putString(KEY_LAST, config.toJson().toString()).apply()
    }

    fun getLastUsed(): BannerConfig? {
        val raw = prefs.getString(KEY_LAST, null) ?: return null
        return try {
            BannerConfig.fromJson(JSONObject(raw))
        } catch (e: Exception) {
            null
        }
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_LIST = "banner_list"
        private const val KEY_LAST = "last_used"
    }
}
