package com.arif.ledtvbanner.media

import android.os.Handler
import android.os.Looper
import com.arif.ledtvbanner.data.RadioStation
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * Fetches ready-made internet radio stations from the public Radio Browser API.
 * Uses several mirror servers so one outage does not break the feature.
 */
object RadioBrowserClient {

    private val SERVERS = listOf(
        "https://de1.api.radio-browser.info",
        "https://de2.api.radio-browser.info",
        "https://nl1.api.radio-browser.info"
    )

    val CATEGORIES = listOf(
        "Slow Romantik", "Hareketli Romantik", "Lounge / Cafe", "Chill / Relax",
        "Türkçe Pop", "Yabancı Pop", "Klasik Müzik", "80'ler / 90'lar",
        "Enstrümantal", "Arabesk / Damar", "Karışık Radyo"
    )

    private fun queriesFor(category: String): List<String> = when (category) {
        "Slow Romantik" -> listOf(
            "/json/stations/search?tag=love&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=romantic&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=soft&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=slow&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Hareketli Romantik" -> listOf(
            "/json/stations/search?tag=romantic&hidebroken=true&order=votes&reverse=true&limit=30",
            "/json/stations/search?tag=dance&hidebroken=true&order=votes&reverse=true&limit=30",
            "/json/stations/search?tag=hits&hidebroken=true&order=votes&reverse=true&limit=30",
            "/json/stations/search?tag=pop&hidebroken=true&order=votes&reverse=true&limit=30"
        )
        "Lounge / Cafe" -> listOf(
            "/json/stations/search?tag=lounge&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=cafe&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=smooth&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=chillout&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Chill / Relax" -> listOf(
            "/json/stations/search?tag=chillout&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=relax&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=ambient&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=downtempo&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Türkçe Pop" -> listOf(
            "/json/stations/search?countrycode=TR&tag=pop&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?countrycode=TR&tag=turkish&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?countrycode=TR&name=pop&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Yabancı Pop" -> listOf(
            "/json/stations/search?tag=pop&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=hits&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=top40&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Klasik Müzik" -> listOf(
            "/json/stations/search?tag=classical&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=classic&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "80'ler / 90'lar" -> listOf(
            "/json/stations/search?tag=80s&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=90s&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=oldies&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Enstrümantal" -> listOf(
            "/json/stations/search?tag=instrumental&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=piano&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?tag=jazz&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Arabesk / Damar" -> listOf(
            "/json/stations/search?countrycode=TR&tag=arabesk&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?countrycode=TR&tag=turkish&hidebroken=true&order=clickcount&reverse=true&limit=30",
            "/json/stations/search?countrycode=TR&name=arabesk&hidebroken=true&order=clickcount&reverse=true&limit=30"
        )
        "Karışık Radyo" -> listOf(
            "/json/stations/topclick/30",
            "/json/stations/topvote/30"
        )
        else -> listOf("/json/stations/topclick/30")
    }

    fun fetchCategory(
        category: String,
        onResult: (List<RadioStation>) -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            val handler = Handler(Looper.getMainLooper())
            try {
                val out = LinkedHashMap<String, RadioStation>()
                for (q in queriesFor(category)) {
                    val json = fetchWithFallback(q) ?: continue
                    parseInto(json, out)
                    if (out.size >= 30) break
                }
                val list = out.values.toList()
                handler.post {
                    if (list.isEmpty())
                        onError("Bu kategori için radyo bulunamadı. İnternet bağlantısını kontrol edin.")
                    else onResult(list)
                }
            } catch (e: Exception) {
                handler.post { onError("Radyo listesi alınamadı. İnternet bağlantısını kontrol edin.") }
            }
        }.start()
    }

    private fun fetchWithFallback(path: String): String? {
        for (server in SERVERS) {
            try {
                val conn = URL(server + path).openConnection() as HttpURLConnection
                conn.connectTimeout = 6000
                conn.readTimeout = 8000
                conn.requestMethod = "GET"
                conn.setRequestProperty("User-Agent", "LEDTVBanner/1.0")
                val code = conn.responseCode
                if (code in 200..299) {
                    val text = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    return text
                }
                conn.disconnect()
            } catch (_: Exception) {
                // try next server
            }
        }
        return null
    }

    private fun parseInto(json: String, out: LinkedHashMap<String, RadioStation>) {
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url_resolved", "").ifBlank { o.optString("url", "") }
                if (url.isBlank()) continue
                val name = o.optString("name", "").trim()
                if (name.isBlank()) continue
                if (out.containsKey(url)) continue
                out[url] = RadioStation(
                    name = name,
                    country = o.optString("countrycode", ""),
                    codec = o.optString("codec", ""),
                    bitrate = o.optInt("bitrate", 0),
                    url = url,
                    tags = o.optString("tags", "")
                )
            }
        } catch (_: Exception) {
        }
    }
}
