package com.arif.ledtvbanner.banner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import com.arif.ledtvbanner.data.Background
import com.arif.ledtvbanner.data.BannerConfig
import com.arif.ledtvbanner.data.FrameEffect
import com.arif.ledtvbanner.data.LedEffect
import com.arif.ledtvbanner.data.RenderMode
import com.arif.ledtvbanner.data.ScrollDirection
import com.arif.ledtvbanner.data.TextSize

/**
 * Draws the scrolling banner text.
 *
 * Default render mode is READABLE_LED: the text is drawn DIRECTLY with
 * Canvas.drawText (crisp, antialiased, with a thin dark outline and a light
 * glow). This keeps letters legible from across the room and shows Turkish
 * characters (Ç Ğ İ Ö Ş Ü) cleanly.
 *
 * DOT_MATRIX is the old "LED dots" look and is only used if the user picks it.
 * The animated frame and clipping (text stays inside the border) are unchanged.
 */
class LedBannerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var config: BannerConfig = BannerConfig()
        set(value) {
            field = value
            textBitmap = null
            resetScroll()
            invalidate()
        }

    private var paused = false

    // ---- Paints for direct text (readable modes) ----
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.LEFT }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; textAlign = Paint.Align.LEFT; color = Color.BLACK
    }
    private val textGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; textAlign = Paint.Align.LEFT
    }

    // ---- Paints for dot-matrix mode ----
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textRenderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.LEFT }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 20, 20); strokeWidth = 1f
    }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var textBitmap: Bitmap? = null
    private var textCols = 0
    private var ledRows = 0

    private var scrollOffset = 0f          // PIXELS now
    private var lastFrameNanos = 0L
    private var blinkOn = true
    private var blinkTimer = 0f
    private var hue = 0f
    private var currentGlow = false
    private var currentLitColor = Color.RED

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (lastFrameNanos == 0L) lastFrameNanos = frameTimeNanos
            val dt = (frameTimeNanos - lastFrameNanos) / 1_000_000_000f
            lastFrameNanos = frameTimeNanos
            if (!paused) advance(dt)
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        lastFrameNanos = 0L
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stop() { Choreographer.getInstance().removeFrameCallback(frameCallback) }

    fun togglePause() { paused = !paused }
    fun isPaused() = paused

    override fun onAttachedToWindow() { super.onAttachedToWindow(); start() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }

    private fun resetScroll() { scrollOffset = 0f; lastFrameNanos = 0L }

    private fun advance(dt: Float) {
        blinkTimer += dt
        if (blinkTimer >= 0.5f) { blinkTimer = 0f; blinkOn = !blinkOn }
        hue = (hue + dt * 60f) % 360f
        if (config.direction != ScrollDirection.BLINK_STATIC) {
            scrollOffset += config.speed.pixelsPerSecond * dt
        }
    }

    private fun pitchPx(): Float {
        val rows = config.size.ledRows
        val usable = height * config.size.bandFraction
        return if (rows > 0) usable / rows else 0f
    }

    // ============================================================
    //  DRAW
    // ============================================================

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawBackground(canvas)
        if (width == 0 || height == 0) return

        currentLitColor = currentTextColor()

        val frameOn = config.frameEffect != FrameEffect.OFF
        val margin = if (frameOn) {
            val t = (minOf(width, height) * 0.016f).coerceAtLeast(10f)
            minOf(width, height) * 0.05f + t + minOf(width, height) * 0.02f
        } else height * 0.04f

        canvas.save()
        canvas.clipRect(margin, margin, width - margin, height - margin)
        if (config.renderMode == RenderMode.DOT_MATRIX) {
            drawDotMode(canvas)
        } else {
            drawReadable(canvas, margin)
        }
        canvas.restore()

        drawFrame(canvas)
    }

    // ---------- READABLE (direct drawText) ----------

    private fun drawReadable(canvas: Canvas, margin: Float) {
        val innerLeft = margin
        val innerRight = width - margin
        val innerTop = margin
        val innerBottom = height - margin
        val innerW = innerRight - innerLeft
        val innerH = innerBottom - innerTop
        if (innerW <= 0 || innerH <= 0) return

        // Letter height ~ 45-60% of the inner area.
        val frac = when (config.size) {
            TextSize.SMALL -> 0.36f
            TextSize.MEDIUM -> 0.46f
            TextSize.LARGE -> 0.55f
            TextSize.HUGE -> 0.64f
        }
        val ts = innerH * frac

        val tf = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        for (p in listOf(fillPaint, outlinePaint, textGlowPaint)) {
            p.typeface = tf
            p.textSize = ts
            p.letterSpacing = 0.02f
        }

        val text = (if (config.text.isEmpty()) " " else config.text).replace("\n", "   ")
        val tw = fillPaint.measureText(text)
        val fm = fillPaint.fontMetrics
        val color = currentLitColor

        // Whole-text blink
        val blink = config.ledEffect == LedEffect.BLINK || config.direction == ScrollDirection.BLINK_STATIC
        if (blink && !blinkOn) return

        val vertical = config.direction == ScrollDirection.TOP_TO_BOTTOM ||
                config.direction == ScrollDirection.BOTTOM_TO_TOP

        if (config.direction == ScrollDirection.BLINK_STATIC) {
            val x = innerLeft + (innerW - tw) / 2f
            val baseY = innerTop + innerH / 2f - (fm.ascent + fm.descent) / 2f
            drawTextLayers(canvas, text, x, baseY, color, ts)
            return
        }

        if (!vertical) {
            val baseY = innerTop + innerH / 2f - (fm.ascent + fm.descent) / 2f
            val gap = innerW * 0.6f
            val period = tw + gap
            if (period <= 0f) return
            val o = ((scrollOffset % period) + period) % period
            val leftToRight = config.direction == ScrollDirection.LEFT_TO_RIGHT
            val anchor = if (leftToRight) (innerLeft - tw + o) else (innerRight - o)
            var x = anchor
            while (x > innerLeft - tw - period) x -= period
            while (x < innerRight + period) {
                if (x + tw > innerLeft && x < innerRight) {
                    drawTextLayers(canvas, text, x, baseY, color, ts)
                }
                x += period
            }
        } else {
            // Vertical scroll of the whole line, horizontally centred.
            val x = innerLeft + (innerW - tw) / 2f
            val lineH = ts
            val travel = innerH + lineH * 2f
            val o = ((scrollOffset % travel) + travel) % travel
            val up = config.direction == ScrollDirection.BOTTOM_TO_TOP
            val topY = if (up) (innerBottom - o) else (innerTop - lineH + o)
            val baseY = topY + (-fm.ascent)
            if (baseY + fm.descent > innerTop && baseY + fm.ascent < innerBottom) {
                drawTextLayers(canvas, text, x, baseY, color, ts)
            }
        }
    }

    /** Soft glow (shadow, no glyph thickening) + thin dark outline + colour fill.
     *  Shadow glow keeps the dots on Ç Ğ İ Ö Ş Ü separate from the letter body. */
    private fun drawTextLayers(canvas: Canvas, text: String, x: Float, baseY: Float, color: Int, ts: Float) {
        val mode = config.renderMode
        // 1) Glow as a shadow layer — does NOT expand the glyph outline, so the
        //    little dots above ü/ö/İ never merge into the letter.
        if (mode == RenderMode.NEON || mode == RenderMode.READABLE_LED) {
            val blur = if (mode == RenderMode.NEON) ts * 0.18f else ts * 0.10f
            fillPaint.style = Paint.Style.FILL
            fillPaint.color = color
            fillPaint.alpha = 255
            fillPaint.setShadowLayer(blur, 0f, 0f, color)
            canvas.drawText(text, x, baseY, fillPaint)
            fillPaint.clearShadowLayer()
        }
        // 2) Very thin dark outline for crisp edges (thin = dots stay separate).
        outlinePaint.style = Paint.Style.STROKE
        outlinePaint.color = Color.BLACK
        outlinePaint.alpha = 220
        outlinePaint.strokeWidth = ts * 0.028f
        canvas.drawText(text, x, baseY, outlinePaint)

        // 3) Crisp colour fill on top.
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = color
        fillPaint.alpha = 255
        canvas.drawText(text, x, baseY, fillPaint)
    }

    // ---------- DOT MATRIX (old look, optional) ----------

    private fun drawDotMode(canvas: Canvas) {
        if (textBitmap == null) buildTextBitmap()
        val bmp = textBitmap ?: return
        val pitch = pitchPx()
        if (pitch <= 0f) return
        val radius = pitch * 0.38f
        ledRows = config.size.ledRows
        val screenCols = (width / pitch).toInt() + 2
        val topMargin = (height - ledRows * pitch) / 2f

        val blinkEffect = config.ledEffect == LedEffect.BLINK ||
                config.direction == ScrollDirection.BLINK_STATIC
        if (blinkEffect && !blinkOn) return
        currentGlow = config.ledEffect == LedEffect.NEON_GLOW || config.ledEffect == LedEffect.BLUR_GLOW

        val vertical = config.direction == ScrollDirection.TOP_TO_BOTTOM ||
                config.direction == ScrollDirection.BOTTOM_TO_TOP
        if (vertical) drawDotsVertical(canvas, bmp, pitch, radius)
        else drawDotsHorizontal(canvas, bmp, pitch, radius, topMargin, screenCols)
    }

    private fun buildTextBitmap() {
        ledRows = config.size.ledRows
        textRenderPaint.typeface =
            if (config.bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
        textRenderPaint.letterSpacing = 0.08f
        val text = if (config.text.isEmpty()) " " else config.text.replace("\n", "  ")
        val scale = 3
        textRenderPaint.textSize = (ledRows * scale).toFloat()
        val fm = textRenderPaint.fontMetrics
        val wHi = Math.max(scale, Math.ceil(textRenderPaint.measureText(text).toDouble()).toInt() + scale * 2)
        val hHi = ledRows * scale
        val hi = Bitmap.createBitmap(wHi, hHi, Bitmap.Config.ARGB_8888)
        val c = Canvas(hi)
        c.drawColor(Color.TRANSPARENT)
        val baseline = (hHi - (fm.ascent + fm.descent)) / 2f
        c.drawText(text, scale.toFloat(), baseline, textRenderPaint)
        val w = Math.max(1, wHi / scale)
        val bmp = Bitmap.createScaledBitmap(hi, w, ledRows, true)
        hi.recycle()
        textBitmap = bmp
        textCols = w
    }

    private fun drawDotsHorizontal(
        canvas: Canvas, bmp: Bitmap, pitch: Float, radius: Float, topMargin: Float, screenCols: Int
    ) {
        val dotScroll = scrollOffset / pitch
        if (config.direction == ScrollDirection.BLINK_STATIC) {
            val startCol = (screenCols - textCols) / 2
            for (col in 0 until textCols) {
                val sx = startCol + col
                if (sx < 0 || sx >= screenCols) continue
                val cx = sx * pitch + pitch / 2f
                for (row in 0 until ledRows) if (isLit(bmp, col, row)) {
                    drawDot(canvas, cx, topMargin + row * pitch + pitch / 2f, radius)
                }
            }
            return
        }
        val gap = (screenCols / 2).coerceAtLeast(8)
        val strip = textCols + gap
        if (strip <= 0) return
        val phase = ((dotScroll % strip) + strip) % strip
        val leftToRight = config.direction == ScrollDirection.LEFT_TO_RIGHT
        for (sx in 0 until screenCols) {
            val raw = if (leftToRight) (sx - phase) else (sx + phase)
            var pos = (Math.floor(raw.toDouble()).toInt()) % strip
            if (pos < 0) pos += strip
            if (pos >= textCols) continue
            val cx = sx * pitch + pitch / 2f
            for (row in 0 until ledRows) if (isLit(bmp, pos, row)) {
                drawDot(canvas, cx, topMargin + row * pitch + pitch / 2f, radius)
            }
        }
    }

    private fun drawDotsVertical(canvas: Canvas, bmp: Bitmap, pitch: Float, radius: Float) {
        val dotScroll = scrollOffset / pitch
        val screenRows = (height / pitch).toInt() + 2
        val screenColsTotal = (width / pitch).toInt() + 2
        val startCol = (screenColsTotal - textCols) / 2
        val gap = (screenRows / 2).coerceAtLeast(6)
        val travel = ledRows + screenRows + gap
        if (travel <= 0) return
        val phase = ((dotScroll % travel) + travel) % travel
        val upward = config.direction == ScrollDirection.BOTTOM_TO_TOP
        val topRow = if (upward) (screenRows - phase) else (phase - ledRows)
        for (row in 0 until ledRows) {
            val sr = Math.round(topRow + row)
            if (sr < 0 || sr >= screenRows) continue
            val cy = sr * pitch + pitch / 2f
            for (col in 0 until textCols) if (isLit(bmp, col, row)) {
                val sx = startCol + col
                if (sx < 0 || sx >= screenColsTotal) continue
                drawDot(canvas, sx * pitch + pitch / 2f, cy, radius)
            }
        }
    }

    private fun drawDot(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        if (currentGlow) {
            glowPaint.color = currentLitColor
            glowPaint.alpha = 30
            canvas.drawCircle(cx, cy, radius * 1.18f, glowPaint)
        }
        dotPaint.color = currentLitColor
        dotPaint.alpha = 255
        canvas.drawCircle(cx, cy, radius, dotPaint)
        dotPaint.color = blendWhite(currentLitColor, 0.5f)
        canvas.drawCircle(cx, cy, radius * 0.42f, dotPaint)
    }

    private fun blendWhite(c: Int, t: Float): Int {
        val r = (Color.red(c) * (1 - t) + 255 * t).toInt().coerceIn(0, 255)
        val g = (Color.green(c) * (1 - t) + 255 * t).toInt().coerceIn(0, 255)
        val b = (Color.blue(c) * (1 - t) + 255 * t).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun isLit(bmp: Bitmap, col: Int, row: Int): Boolean {
        if (col < 0 || col >= bmp.width || row < 0 || row >= bmp.height) return false
        return Color.alpha(bmp.getPixel(col, row)) > 100
    }

    // ---------- shared ----------

    private fun currentTextColor(): Int {
        return if (config.textColor.isCycle || config.ledEffect == LedEffect.COLOR_CYCLE) {
            Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        } else {
            config.textColor.color
        }
    }

    private fun drawBackground(canvas: Canvas) {
        when (config.background) {
            Background.BLACK, Background.YOUTUBE_DIM -> {
                bgPaint.color = Color.BLACK
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
            Background.DARK_GRAY -> {
                bgPaint.color = Color.rgb(18, 18, 20)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
            Background.REFLECTIVE -> {
                bgPaint.color = Color.rgb(10, 12, 16)
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
            }
            Background.LED_GRID -> {
                bgPaint.color = Color.BLACK
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
                val step = pitchPx().coerceAtLeast(8f)
                var x = 0f
                while (x < width) { canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint); x += step }
                var y = 0f
                while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, gridPaint); y += step }
            }
        }
    }

    private fun drawFrame(canvas: Canvas) {
        if (config.frameEffect == FrameEffect.OFF) return
        val t = (minOf(width, height) * 0.016f).coerceAtLeast(10f)
        framePaint.style = Paint.Style.STROKE
        framePaint.strokeWidth = t
        val color = when (config.frameEffect) {
            FrameEffect.COLOR_CHANGING -> Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
            FrameEffect.BLINKING -> if (blinkOn) Color.rgb(255, 40, 40) else Color.rgb(40, 40, 40)
            else -> Color.rgb(60, 120, 255)
        }
        framePaint.color = color
        framePaint.clearShadowLayer()
        // Keep the frame well inside the panel so TV overscan can't crop it.
        val inset = minOf(width, height) * 0.05f + t / 2f
        if (config.frameEffect == FrameEffect.RUNNING_DOTS) {
            drawRunningDots(canvas, inset, t)
        } else {
            canvas.drawRect(inset, inset, width - inset, height - inset, framePaint)
        }
    }

    private fun drawRunningDots(canvas: Canvas, inset: Float, t: Float) {
        framePaint.style = Paint.Style.FILL
        val gap = t * 2.2f
        val r = t * 0.5f
        val phase = (scrollOffset * 0.5f) % (gap * 2f)
        var x = inset + phase
        while (x < width - inset) {
            framePaint.color = Color.HSVToColor(floatArrayOf((hue + x) % 360f, 1f, 1f))
            canvas.drawCircle(x, inset, r, framePaint)
            canvas.drawCircle(x, height - inset, r, framePaint)
            x += gap
        }
        var y = inset + phase
        while (y < height - inset) {
            framePaint.color = Color.HSVToColor(floatArrayOf((hue + y) % 360f, 1f, 1f))
            canvas.drawCircle(inset, y, r, framePaint)
            canvas.drawCircle(width - inset, y, r, framePaint)
            y += gap
        }
    }

    // ---- External controls (D-pad) ----
    fun increaseSpeed() {
        val v = com.arif.ledtvbanner.data.ScrollSpeed.values()
        val i = v.indexOf(config.speed); if (i < v.size - 1) config.speed = v[i + 1]
    }
    fun decreaseSpeed() {
        val v = com.arif.ledtvbanner.data.ScrollSpeed.values()
        val i = v.indexOf(config.speed); if (i > 0) config.speed = v[i - 1]
    }
    fun increaseSize() {
        val v = TextSize.values()
        val i = v.indexOf(config.size); if (i < v.size - 1) { config.size = v[i + 1]; textBitmap = null }
    }
    fun decreaseSize() {
        val v = TextSize.values()
        val i = v.indexOf(config.size); if (i > 0) { config.size = v[i - 1]; textBitmap = null }
    }
}
